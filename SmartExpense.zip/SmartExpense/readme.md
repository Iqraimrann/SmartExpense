# 💸 SmartExpense – Personal Finance & Budget Tracker

SmartExpense is a full-stack Django-based web application designed for individuals, families, and small teams to track expenses, manage budgets, and get financial insights in a simple and smart way.

---

## 🚀 Features (15 Key Modules)

1. ✅ **User Registration & Login**
2. ✅ **Add Expenses**
3. ✅ **Add Income**
4. ✅ **Expense Categories**
5. ✅ **Dashboard with Pie Chart**
6. ✅ **Expense History Table**
7. ✅ **Recurring Expense Option**
8. ✅ **Budget Setup & Overspending Alerts**
9. ✅ **Export to CSV**
10. ✅ **Password Change & Profile Settings**
11. ✅ **Spending Prediction (Simple AI Rule-Based)**
12. ✅ **Edit & Delete Expense/Income**
13. ✅ **Light/Dark Mode Toggle**
14. ✅ **Feedback Form**
15. ✅ **Predictive Insights Based on Past Spending**

---

## 📊 Tech Stack

- **Backend:** Django 5.x
- **Frontend:** HTML, CSS, Chart.js
- **Database:** SQLite
- **Authentication:** Django Auth system
- **AI Insight:** Rule-based spending prediction

---

## 🔧 Setup Instructions (Local Machine)

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/smartexpense.git
cd smartexpense
