from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.http import HttpResponse
from .forms import ExpenseForm, IncomeForm, BudgetForm
from .models import Expense, Income, Budget
import csv
from django.utils import timezone
from datetime import timedelta
import json

# --------------------- Dashboard View  ---------------------

@login_required
def dashboard(request):
    from .models import Expense, Income, Budget  # ✅ Ensure models are imported

    total_income = Income.objects.filter(user=request.user).aggregate(Sum('amount'))['amount__sum'] or 0
    total_expense = Expense.objects.filter(user=request.user).aggregate(Sum('amount'))['amount__sum'] or 0

    # ✅ Get category totals for chart
    category_data = Expense.objects.filter(user=request.user).values('category').annotate(total=Sum('amount'))
    labels = json.dumps([item['category'] for item in category_data])  # Proper JSON string for JS
    totals = json.dumps([item['total'] for item in category_data])

    # ✅ Get recent expenses
    recent_expenses = Expense.objects.filter(user=request.user).order_by('-date')[:5]

    # ✅ Budget alerts
    alerts = []
    budgets = Budget.objects.filter(user=request.user)
    for budget in budgets:
        spent = Expense.objects.filter(user=request.user, category=budget.category).aggregate(Sum('amount'))['amount__sum'] or 0
        if spent > budget.limit:
            alerts.append(f"⚠️ Overspent in category: {budget.category}")

    return render(request, 'tracker/dashboard.html', {
        'total_income': total_income,
        'total_expense': total_expense,
        'labels': labels,  # ✅ json string
        'totals': totals,  # ✅ json string
        'recent_expenses': recent_expenses,
        'alerts': alerts
    })


# --------------------- Add Income ---------------------

@login_required
def add_income(request):
    if request.method == 'POST':
        form = IncomeForm(request.POST)
        if form.is_valid():
            income = form.save(commit=False)
            income.user = request.user
            income.save()
            return redirect('dashboard')
    else:
        form = IncomeForm()
    return render(request, 'tracker/add_income.html', {'form': form})

# --------------------- Add Expense ---------------------

@login_required
def add_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            return redirect('dashboard')
    else:
        form = ExpenseForm()
    return render(request, 'tracker/add_expense.html', {'form': form})

# --------------------- Edit Expense ---------------------

@login_required
def edit_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = ExpenseForm(instance=expense)
    return render(request, 'tracker/add_expense.html', {'form': form})

# --------------------- Delete Expense ---------------------

@login_required
def delete_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    expense.delete()
    return redirect('dashboard')

# --------------------- Expense History ---------------------

@login_required
def expense_history(request):
    expenses = Expense.objects.filter(user=request.user).order_by('-date')
    return render(request, 'tracker/expense_history.html', {'expenses': expenses})

# --------------------- Export to CSV ---------------------

@login_required
def export_expenses_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="expenses.csv"'

    writer = csv.writer(response)
    writer.writerow(['Category', 'Amount', 'Date', 'Recurring'])

    expenses = Expense.objects.filter(user=request.user)
    for expense in expenses:
        writer.writerow([expense.category, expense.amount, expense.date, expense.recurring])

    return response

# --------------------- Set Budget ---------------------

@login_required
def set_budget(request):
    if request.method == 'POST':
        form = BudgetForm(request.POST)
        if form.is_valid():
            budget = form.save(commit=False)
            budget.user = request.user
            budget.save()
            return redirect('dashboard')
    else:
        form = BudgetForm()
    return render(request, 'tracker/set_budget.html', {'form': form})

# --------------------- Predictive Insights ---------------------

@login_required
def predictive_insights(request):
    today = timezone.now().date()
    start_of_month = today.replace(day=1)

    expenses = Expense.objects.filter(user=request.user, date__gte=start_of_month)
    insights = []

    top_category = expenses.values('category').annotate(total=Sum('amount')).order_by('-total').first()
    if top_category:
        insights.append(f"You spent the most on '{top_category['category']}' this month: Rs {top_category['total']}")

    budgets = Budget.objects.filter(user=request.user)
    for budget in budgets:
        spent = expenses.filter(category=budget.category).aggregate(total=Sum('amount'))['total'] or 0
        if spent > budget.limit:
            insights.append(f"⚠️ You exceeded your budget for '{budget.category}'. Spent: Rs {spent}, Limit: Rs {budget.limit}")

    if not insights:
        insights.append("👍 Everything looks good this month. Keep it up!")

    return render(request, 'tracker/predictive_insights.html', {'insights': insights})

from django.views.decorators.http import require_POST

@require_POST
def toggle_theme(request):
    current = request.session.get('theme', 'light')
    request.session['theme'] = 'dark' if current == 'light' else 'light'
    return redirect(request.META.get('HTTP_REFERER', 'dashboard'))

from .forms import FeedbackForm
from .models import Feedback

@login_required
def feedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.user = request.user
            feedback.save()
            return redirect('dashboard')
    else:
        form = FeedbackForm()
    return render(request, 'tracker/feedback.html', {'form': form})

from .forms import RegisterForm
from django.contrib.auth import login

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Auto login after registration
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'tracker/register.html', {'form': form})
