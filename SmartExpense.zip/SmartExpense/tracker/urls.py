from django.urls import path
from . import views

urlpatterns = [
    path('add-expense/', views.add_expense, name='add_expense'),
    path('add-income/', views.add_income, name='add_income'),
    path('dashboard/', views.dashboard, name='dashboard'), 
    path('edit-expense/<int:pk>/', views.edit_expense, name='edit_expense'),
    path('delete-expense/<int:pk>/', views.delete_expense, name='delete_expense'),
    path('expense-history/', views.expense_history, name='expense_history'),
    path('export-csv/', views.export_expenses_csv, name='export_csv'),
    path('set-budget/', views.set_budget, name='set_budget'),
    path('predictive-insights/', views.predictive_insights, name='predictive_insights'),
    path('toggle-theme/', views.toggle_theme, name='toggle_theme'),
    path('feedback/', views.feedback, name='feedback'),
    path('register/', views.register, name='register'),

]
from django.contrib.auth import views as auth_views

urlpatterns += [
    path('password-change/', auth_views.PasswordChangeView.as_view(template_name='tracker/password_change.html'), name='password_change'),
    path('password-change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='tracker/password_change_done.html'), name='password_change_done'),
]

